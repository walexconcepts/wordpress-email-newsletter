<?php
	
?>
<br>
<br>
<div style="float:none" class="well center-block col-md-7">
<h3>Help - User Guide</h3>

== <b>Description</b> ==
<p>
Thank you for installing Email Subscribers & Newsletters Broadcasts. ESNB help you achieve all your newsletter related tasks effectively in one 
single place. Please visit [demo](https://izzumes.com/ng/index.php?page=item&id=253/).
</p>


Free Version features:
<p>
<ul>
<li>* NO cron job and scheduling</li>
<li>* Easily collect emails by adding a subscription form** to your page using shortcode or php code</li>
<li>* HTML editor to compose newsletters or add sample template.</li>
<li>* Send beautifully crafted HTML newsletters to your subscribers instantly</li>
<li>* Send newsletters using (simple mail transfer protocol) SMTp</li>
<li>* Send email to all users.</li>
<li>* Html block form subscription form at frontend.</li>
</ul>
</p>

Premium Features:
<p>
<ul>
<li>* All of te above free version features. </li>
<li>* Preview newsletter before sending email to users.</li>
<li>* Check email status when it was viewed so called tracking.</li>
<li>* Unsubscribe link in the mail.
<li>* Send email to all or specific users.</li>
<li>* Template for Woocommerce latest products while sending a newsletter.
<li>* Three different options to display subscription form at frontend.</li>
</ul>
</p>

</div>
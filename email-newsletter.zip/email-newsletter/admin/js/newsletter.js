// JavaScript Document
function newsletter()
{
	var cond=true;
	if(document.newsletter.varsubject.value.length==0)
	{
		alert("Please Enter Subject.");
		if(cond==true)
		{
			document.newsletter.varsubject.focus();
		}
		cond=false;
		return false;
	}	
	
	if(document.newsletter.vartext.value==0)
	//if(document.getElementById("newsletter").vartext.value.length==0)
	{
		alert("Please Enter Text Message.");
		if(cond==true)
		{
			document.newsletter.vartext.focus();
		}
		cond=false;
		return false;
	}
}
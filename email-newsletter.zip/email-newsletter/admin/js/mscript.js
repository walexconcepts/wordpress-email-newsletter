function mmLoadMenus() 
{
  if (window.mm_menu_0601121012_0) return;
                        window.mm_menu_0601121012_0 = new Menu("root",132,25,"Verdana, Arial, Helvetica, sans-serif",10,"#FFFFFF","#cccccc","#999999","#ffffff","left","middle",3,0,500,-5,7,true,true,true,0,true,true);
  mm_menu_0601121012_0.addMenuItem("Store Settings","location='store.php'");
  
  //mm_menu_0601121012_0.addMenuItem("Images","location='imagesetting.php'");
 mm_menu_0601121012_0.addMenuItem("Page Setting","location='page.php'");
 mm_menu_0601121012_0.addMenuItem("FAQ's","location='faq.php'");
 mm_menu_0601121012_0.addMenuItem("Images","location='imagesetting.php'");
 //mm_menu_0601121012_0.addMenuItem("E-Mail Setting","location='emailsetting.php'");
   mm_menu_0601121012_0.fontWeight="bold";
   mm_menu_0601121012_0.hideOnMouseOut=true;
   mm_menu_0601121012_0.bgColor='#555555';
   mm_menu_0601121012_0.menuBorder=1;
   mm_menu_0601121012_0.menuLiteBgColor='#FFFFFF';
   mm_menu_0601121012_0.menuBorderBgColor='#777777';

  window.mm_menu_0601125140_0 = new Menu("root",132,25,"Verdana, Arial, Helvetica, sans-serif",10,"#ffffff","#cccccc","#999999","#ffffff","left","middle",3,0,500,-5,7,true,true,true,0,true,true);
 mm_menu_0601125140_0.addMenuItem("Products","location='product.php'");
  mm_menu_0601125140_0.addMenuItem("Category","location='category.php'");
  mm_menu_0601125140_0.addMenuItem("Product Attributes","location='prodattribute.php'");
   mm_menu_0601125140_0.addMenuItem("Brands","location='manufacture.php'");
   mm_menu_0601125140_0.addMenuItem("Gift Ideas","location='ideas.php'");
   
	//mm_menu_0601125140_0.addMenuItem("Discount Code","location='discountcode.php'");
	mm_menu_0601125140_0.addMenuItem("Related Products","location='relatedproducts.php'");
   mm_menu_0601125140_0.fontWeight="bold";
   mm_menu_0601125140_0.hideOnMouseOut=true;
   mm_menu_0601125140_0.bgColor='#666666';
   mm_menu_0601125140_0.menuBorder=1;
   mm_menu_0601125140_0.menuLiteBgColor='#FFFFFF';
   mm_menu_0601125140_0.menuBorderBgColor='#666666';

      window.mm_menu_0601130347_0 = new Menu("root",132,25,"Verdana, Arial, Helvetica, sans-serif",10,"#ffffff","#cccccc","#999999","#ffffff","left","middle",3,0,500,-5,7,true,true,true,0,true,true);
	 mm_menu_0601130347_0 .addMenuItem("Discount Code","location='discountcode.php'");
  mm_menu_0601130347_0.addMenuItem("Payment","location='paypalsetting.php'");
  mm_menu_0601130347_0.addMenuItem("Shipping","location='shipping.php'");
  mm_menu_0601130347_0.addMenuItem("VAT Rate","location='tax.php'");
  mm_menu_0601130347_0.addMenuItem("Currencies","location='currency.php'");
  //mm_menu_0601130347_0.addMenuItem("Order Status","location='orderstatusmodule.php'");
  
   mm_menu_0601130347_0.fontWeight="bold";
   mm_menu_0601130347_0.hideOnMouseOut=true;
   mm_menu_0601130347_0.bgColor='#666666';
   mm_menu_0601130347_0.menuBorder=1;
   mm_menu_0601130347_0.menuLiteBgColor='#FFFFFF';
   mm_menu_0601130347_0.menuBorderBgColor='#666666';

          window.mm_menu_0601131633_0 = new Menu("root",132,25,"Verdana, Arial, Helvetica, sans-serif",10,"#ffffff","#cccccc","#999999","#ffffff","left","middle",3,0,500,-5,7,true,true,true,0,true,true);
  mm_menu_0601131633_0.addMenuItem("Customers","location='customer.php'");
 mm_menu_0601131633_0.addMenuItem("Create New Account","location='customer.php?script=addcustomer'");
  
  
   mm_menu_0601131633_0.fontWeight="bold";
   mm_menu_0601131633_0.hideOnMouseOut=true;
   mm_menu_0601131633_0.bgColor='#666666';
   mm_menu_0601131633_0.menuBorder=1;
   mm_menu_0601131633_0.menuLiteBgColor='#FFFFFF';
   mm_menu_0601131633_0.menuBorderBgColor='#666666';
   
   
   window.mm_menu_0601131634_0 = new Menu("root",132,25,"Verdana, Arial, Helvetica, sans-serif",10,"#ffffff","#cccccc","#999999","#F08380","left","middle",3,0,500,-5,7,true,true,true,0,true,true);
  //mm_menu_0601131634_0.addMenuItem("Country","location='country.php'");
//  mm_menu_0601131634_0.addMenuItem("Tax Classes","location='tax.php'");
  //  mm_menu_0601131634_0.addMenuItem("Tax Rates","location='taxrates.php'");
   mm_menu_0601131634_0.fontWeight="bold";
   mm_menu_0601131634_0.hideOnMouseOut=true;
   mm_menu_0601131634_0.bgColor='#666666';
   mm_menu_0601131634_0.menuBorder=1;
   mm_menu_0601131634_0.menuLiteBgColor='#FFFFFF';
   mm_menu_0601131634_0.menuBorderBgColor='#666666';
   
   
    window.mm_menu_0601131635_0 = new Menu("root",132,25,"Verdana, Arial, Helvetica, sans-serif",10,"#ffffff","#cccccc","#999999","#ffffff","left","middle",3,0,500,-5,7,true,true,true,0,true,true);
  
  //mm_menu_0601131635_0.addMenuItem("Currencies","location='currency.php'");
	//mm_menu_0601131635_0.addMenuItem("Order Status","location='customerreport.php'");
   mm_menu_0601131635_0.fontWeight="bold";
   mm_menu_0601131635_0.hideOnMouseOut=true;
   mm_menu_0601131635_0.bgColor='#666666';
   mm_menu_0601131635_0.menuBorder=1;
   mm_menu_0601131635_0.menuLiteBgColor='#FFFFFF';
   mm_menu_0601131635_0.menuBorderBgColor='#666666';
   
  
   
   window.mm_menu_0601131636_0 = new Menu("root",132,25,"Verdana, Arial, Helvetica, sans-serif",10,"#ffffff","#cccccc","#999999","#ffffff","left","middle",3,0,500,-5,7,true,true,true,0,true,true);
	<!--mm_menu_0601131637_0.addMenuItem("Database Manager","location='dbmanager.php'");--!>
	mm_menu_0601131636_0.addMenuItem("RMA","location='ram.php'");
	mm_menu_0601131636_0.addMenuItem("Order Status","location='customerreport.php'");
	mm_menu_0601131636_0.addMenuItem("Country","location='country.php'");
	mm_menu_0601131636_0.addMenuItem("Product Viewed","location='prodviewed.php'");
  	mm_menu_0601131636_0.addMenuItem("Product Purchased","location='prodpurchased.php'");
  	mm_menu_0601131636_0.addMenuItem("Total Customer Order","location='ordertotal.php'");
	mm_menu_0601131636_0.addMenuItem("Banner Manager","location='banner.php'");
	mm_menu_0601131636_0.fontWeight="bold";
	mm_menu_0601131636_0.hideOnMouseOut=true;
	mm_menu_0601131636_0.bgColor='#666666';
	mm_menu_0601131636_0.menuBorder=1;
	mm_menu_0601131636_0.menuLiteBgColor='#FFFFFF';
	mm_menu_0601131636_0.menuBorderBgColor='#666666';
	
	window.mm_menu_0601131638_0 = new Menu("root",194,25,"Verdana, Arial, Helvetica, sans-serif",9,"#ffffff","#cccccc","#999999","#ffffff","left","middle",3,0,500,-5,7,true,true,true,0,true,true);
	<!--mm_menu_0601131637_0.addMenuItem("Database Manager","location='dbmanager.php'");--!>
	//mm_menu_0601131638_0.addMenuItem("Processing Order Queue("+orderstatus+")","location='orderqueue.php?orderstatus=1'");
	//mm_menu_0601131638_0.addMenuItem("Order processed to supplier Queue("+orderstatus1+")","location='orderqueue.php?orderstatus=2'");
	//mm_menu_0601131638_0.addMenuItem("Dispatch Queue ("+orderstatus2+")","location='orderqueue.php?orderstatus=3'");
	//mm_menu_0601131638_0.addMenuItem("Complete/Historic Queue("+orderstatus3+") ","location='orderqueue.php?orderstatus=4'");
	//mm_menu_0601131638_0.addMenuItem("Supplier queue("+orderstatus4+")","location='orderqueue.php?orderstatus=5'");
	
	mm_menu_0601131638_0.addMenuItem("Processing Order Queue","location='orderqueue.php?orderstatus=1'");
	mm_menu_0601131638_0.addMenuItem("Order processed to supplier Queue","location='orderqueue.php?orderstatus=2'");
	mm_menu_0601131638_0.addMenuItem("Dispatch Queue","location='orderqueue.php?orderstatus=3'");
	mm_menu_0601131638_0.addMenuItem("Complete/Historic Queue","location='orderqueue.php?orderstatus=4'");
	mm_menu_0601131638_0.addMenuItem("Supplier queue","location='orderqueue.php?orderstatus=5'");
	
	//mm_menu_0601131638_0.addMenuItem("Supplier Queue History","location='supplierqueuehis.php?a=6'");
	//mm_menu_0601131638_0.addMenuItem("Add telephone Order","location='telephoneorder.php'");
	mm_menu_0601131638_0.fontWeight="bold";
	mm_menu_0601131638_0.hideOnMouseOut=true;
	mm_menu_0601131638_0.bgColor='#666666';
	mm_menu_0601131638_0.menuBorder=1;
	mm_menu_0601131638_0.menuLiteBgColor='#FFFFFF';
	mm_menu_0601131638_0.menuBorderBgColor='#666666';


		window.mm_menu_0601131644_0 = new Menu("root",140,25,"Verdana, Arial, Helvetica, sans-serif",10,"#ffffff","#cccccc","#999999","#ffffff","left","middle",3,0,500,-7,7,true,true,true,0,true,true);
		  mm_menu_0601131644_0.addMenuItem("Customer Inquiry List","location='contactus.php'");
		  mm_menu_0601131644_0.addMenuItem("E-Mail Manager","location='emailsetting.php'");
		  mm_menu_0601131644_0.addMenuItem("Newsletter Manager","location='newsletter.php'");
		  mm_menu_0601131644_0.addMenuItem("Send Newsletter","location='sendnews.php'");
		  mm_menu_0601131644_0.addMenuItem("Send Mail","location='sendmail.php'");
		   mm_menu_0601131644_0.fontWeight="bold";
		   mm_menu_0601131644_0.hideOnMouseOut=true;
		   mm_menu_0601131644_0.bgColor='#666666';
		   mm_menu_0601131644_0.menuBorder=1;
		   mm_menu_0601131644_0.menuLiteBgColor='#FFFFFF';
		   mm_menu_0601131644_0.menuBorderBgColor='#666666';

mm_menu_0601131633_0.writeMenus();
}
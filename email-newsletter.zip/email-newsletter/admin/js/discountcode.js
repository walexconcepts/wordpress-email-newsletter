// JavaScript Document
function check()
{
	var cond=true;
	if(document.discount.customer.value=="")
	{
		alert("Please Select Customer.");
		if(cond==true)
		{
			document.discount.customer.focus();
		}
		cond=false;
		return false;
	}	
	if(document.discount.disccode.value.length==0 || document.discount.disccode.value.length<6)
	{
		alert("Please Enter Discount Code of minimum 6 values.");
		if(cond==true)
		{
			document.discount.disccode.focus();
		}
		cond=false;
		return false;
	}
	if(document.discount.exipiredate.value.length==0)
	{
		alert("Please Enter Exipire Date.");
		if(cond==true)
		{
			document.discount.exipiredate.focus();
		}
		cond=false;
		return false;
	}
	if(document.discount.discount.value.length==0)
	{
		alert("Please Enter Discount Value.");
		if(cond==true)
		{
			document.discount.discount.focus();
		}
		cond=false;
		return false;
	}
	if(document.discount.minbuy.value.length==0)
	{
		alert("Please Enter Minimum Buy Value.");
		if(cond==true)
		{
			document.discount.minbuy.focus();
		}
		cond=false;
		return false;
	}
	if(document.discount.maxbuy.value.length==0)
	{
		alert("Please Enter Maximum buy value.");
		if(cond==true)
		{
			document.discount.maxbuy.focus();
		}
		cond=false;
		return false;
	}
}
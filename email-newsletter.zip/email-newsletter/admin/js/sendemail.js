function sendemail()
{
	var cond=true;
	if(document.form.newsletter.value == 0)
	{
		alert("Please Select Newsletterr.");
		if(cond==true)
		{
			document.form.newsletter.focus();
		}
		cond=false;
		return false;
	}	
	
	var is_checkedtest3 = $('.test3').is(':checked');
	var is_checkedtest4 = $('.test4').is(':checked');
	if(!is_checkedtest3 && !is_checkedtest4)
	{
		alert("Please select all or atleast 1 subscriber..");
		
		return false;
	}


    
	
	
	
	
	
	
}

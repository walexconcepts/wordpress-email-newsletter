// JavaScript Document


//for the setting the explore types
var DomYes=document.getElementById?1:0;

//FUNCTION FOR THE OPEING THE POP UP WINDOW, WITHOUR REFRESH THE MAIN WINDOW
function windowpopupopen(URL,winName,features)
{
	if(window.open(URL,winName,features))
	{
		return false;	
	}
	
}


//FUNCTION FOR DISPLAY MSG, BUT CHECK NOT EMPTY
function msgemptycheck(msg,cond)
{
	if(Trim(msg)!="")
	{
		if(cond==0)
		{
			alert(msg);
		}
		else if(cond==1)
		{
			return confirm(msg);
		}
	}
}

//FUNCTION FOR CHECKING THE OPERATION OF TRADE ,DISCUSSION AND THE BUY TO NOT TO DONE HIMSELF
function msgoperationdone(coinmember,member,opt)
{
	if(coinmember==member)
	{
		if(opt=="1")
		{
			alert(" You cannot make Trade Offer to own Self ");
		}
		else if(opt=="2")
		{
			alert("You cannot make Buy Offer to own Self");
		}
		else if(opt=="3")
		{
			alert(" You cannot do Discussion with own self");
		}
		return false;
	}
	return true;	
}


//FUNCTION FOR CHECKING THE EMAIL ADDRESS
function checkMail(email,msg)
{
	
	var x = email.value;
	var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	if (filter.test(x))
	{
		return true;
	}
	else
	{
		msgemptycheck(msg,0);
		email.focus();
		return false;
	}
	return true;
}


//FUNCTION FOR CHECKING THE NUMERIC VALUE
function IsNumeric(sText,msg)
{
   var fctext=sText;
   sText=sText.value;
   
   var ValidChars = "0123456789.";
   var IsNumber=true;
   var Char;

 
   for (i = 0; i < sText.length && IsNumber == true; i++) 
      { 
		  Char = sText.charAt(i); 
		  if (ValidChars.indexOf(Char) == -1) 
         {
         	msgemptycheck(msg,0);
			fctext.focus();
			IsNumber = false;
         }
      }
   return IsNumber;
   
}


//FUNCTION FOR COMPARE THE VALUE AS AN ALPHANUMERIC
function alphanumeric(alphane,msg)
{
	var numaric = alphane.value;
	for(var j=0; j<numaric.length; j++)
		{
		  var alphaa = numaric.charAt(j);
		  var hh = alphaa.charCodeAt(0);
		  if((hh > 47 && hh<59) || (hh > 64 && hh<91) || (hh > 96 && hh<123))
		  {
			  
		  }
		else	
		{
			 msgemptycheck(msg,0);
			 alphane.focus();
			 return false;
		 }
		}
	 return true;
}


//FUNCTION FOR COMPARING TWO CNTRL VALUES & check that Not empty
function comparetwocntrl(val1,val2,msg)
{
	var fval1=val1;
	var fval2=val2;
	val1=val1.value;
	val2=val2.value;
	
	if(val1!=val2)
		{
			
			msgemptycheck(msg,0);
			fval1.focus();
			return false;
		}
		else
		{
			
			return true;	
		}
}

//FUNCTION FOR CHECKING THE EMPTY OR NOT, AND ACCRODING TO REQUIRED LENGTH
function isemtpyandlength(val,vlength,msg)
{
	var fval=val;
	val=val.value;
	
	if(vlength <= 0)
	{
		
		if(val.length != 0)
		{
			return true;	
		}
		else
		{
			msgemptycheck(msg,0);
			fval.focus();
			return false;	
		}
	}
	else
	{
		
		if(val.length >= vlength)
		{
			return true;	
		}
		else
		{
			msgemptycheck(msg,0);
			fval.focus();
			return false;	
		}
	}
}


//FUNCTION FOR THE TRIM THE JAVASCRIPT
function Trim(TRIM_VALUE)
{
	if(TRIM_VALUE.length < 1)
	{
		return"";
	}
	TRIM_VALUE = RTrim(TRIM_VALUE);
	TRIM_VALUE = LTrim(TRIM_VALUE);
	if(TRIM_VALUE=="")
	{
		return "";
	}
	else
	{
		return TRIM_VALUE;
	}
} //End Function

function RTrim(VALUE)
{
	var w_space = String.fromCharCode(32);
	var v_length = VALUE.length;
	var strTemp = "";
	if(v_length < 0)
	{
		return"";
	}
	var iTemp = v_length -1;

	while(iTemp > -1)
	{
		if(VALUE.charAt(iTemp) == w_space)
		{
		}
		else
		{
			strTemp = VALUE.substring(0,iTemp +1);
			break;
		}
		iTemp = iTemp-1;

	} //End While
	return strTemp;

} //End Function

function LTrim(VALUE)
{
	var w_space = String.fromCharCode(32);
	if(v_length < 1)
	{
		return"";
	}
	var v_length = VALUE.length;
	var strTemp = "";

	var iTemp = 0;

	while(iTemp < v_length)
	{
		if(VALUE.charAt(iTemp) == w_space)
		{
		}
		else
		{
			strTemp = VALUE.substring(iTemp,v_length);
			break;
		}
		iTemp = iTemp + 1;
	} //End While
	return strTemp;
} //End Function

///////////////////////////////////////////////////////////////////////
////
///						FUNCTION FOR THE CLOCK DISPLAY IN THE BOTTOM OF THE PAGE
////START FROM HERE
///////////////////////////////////////////////////////////////////////

function jsClockGMT(){
	
		  var TimezoneOffset = 0  // adjust for time zone
		  var localTime = new Date()
		  var ms = localTime.getTime() 
					 + (localTime.getTimezoneOffset() * 60000)
					 + TimezoneOffset * 3600000
		  var time =  new Date(ms) 
		  var hour = time.getHours() 
		  var minute = time.getMinutes()
		  var second = time.getSeconds()
		  var temp = "" + ((hour > 12) ? hour - 12 : hour)
		  if(hour==0) temp = "12"
		  if(temp.length==1) temp = " " + temp
		  temp += ((minute < 10) ? ":0" : ":") + minute
		  temp += ((second < 10) ? ":0" : ":") + second
		  temp += (hour >= 12) ? " <span class='timeviewPM'>PM</span>" : " <span class='timeviewAM'>AM</span>"

    if (DomYes) {
  		var time1=document.getElementById('time1');
	} else {
		var time1=document.all['time1'];
	}
	time1.innerHTML=temp;
   setTimeout("jsClockGMT()",1000)
   }  

function clockshangai(){
	
		  var TimezoneOffset = +8  // adjust for time zone
		  var localTime = new Date()
		  var ms = localTime.getTime() 
					 + (localTime.getTimezoneOffset() * 60000)
					 + TimezoneOffset * 3600000
		  var time =  new Date(ms) 
		  var hour = time.getHours() 
		  var minute = time.getMinutes()
		  var second = time.getSeconds()
		  var temp = "" + ((hour > 12) ? hour - 12 : hour)
		  if(hour==0) temp = "12"
		  if(temp.length==1) temp = " " + temp
		  temp += ((minute < 10) ? ":0" : ":") + minute
		  temp += ((second < 10) ? ":0" : ":") + second
		  temp += (hour >= 12) ? " <span class='timeviewPM'>PM</span>" : " <span class='timeviewAM'>AM</span>"

    if (DomYes) {
  		var time1=document.getElementById('time2');
	} else {
		var time1=document.all['time2'];
	}
	time1.innerHTML=temp;
   setTimeout("clockshangai()",1000)
   }  


function clock3(){
	
		  var TimezoneOffset = 10; // adjust for time zone
		  var localTime = new Date()
		  var ms = localTime.getTime() 
					 + (localTime.getTimezoneOffset() * 60000)
					 + TimezoneOffset * 3600000
		  var time =  new Date(ms) 
		  var hour = time.getHours() 
		  var minute = time.getMinutes()
		  var second = time.getSeconds()
		  var temp = "" + ((hour > 12) ? hour - 12 : hour)
		  if(hour==0) temp = "12"
		  if(temp.length==1) temp = " " + temp
		  temp += ((minute < 10) ? ":0" : ":") + minute
		  temp += ((second < 10) ? ":0" : ":") + second
		  temp += (hour >= 12) ? " <span class='timeviewPM'>PM</span>" : " <span class='timeviewAM'>AM</span>"

    if (DomYes) {
  		var time1=document.getElementById('time3');
	} else {
		var time1=document.all['time3'];
	}
	time1.innerHTML=temp;
   setTimeout("clock3()",1000)
   }  


function clock4(){
	
		  var TimezoneOffset =+9; // adjust for time zone
		  var localTime = new Date()
		  var ms = localTime.getTime() 
					 + (localTime.getTimezoneOffset() * 60000)
					 + TimezoneOffset * 3600000
		  var time =  new Date(ms) 
		  var hour = time.getHours() 
		  var minute = time.getMinutes()
		  var second = time.getSeconds()
		  var temp = "" + ((hour > 12) ? hour - 12 : hour)
		  if(hour==0) temp = "12"
		  if(temp.length==1) temp = " " + temp
		  temp += ((minute < 10) ? ":0" : ":") + minute
		  temp += ((second < 10) ? ":0" : ":") + second
		  temp += (hour >= 12) ? " <span class='timeviewPM'>PM</span>" : " <span class='timeviewAM'>AM</span>"

    if (DomYes) {
  		var time1=document.getElementById('time4');
	} else {
		var time1=document.all['time4'];
	}
	time1.innerHTML=temp;
   setTimeout("clock4()",1000)
   }  

function clock5(){
	
		  var TimezoneOffset =-7; // adjust for time zone
		  var localTime = new Date()
		  var ms = localTime.getTime() 
					 + (localTime.getTimezoneOffset() * 60000)
					 + TimezoneOffset * 3600000
		  var time =  new Date(ms) 
		  var hour = time.getHours() 
		  var minute = time.getMinutes()
		  var second = time.getSeconds()
		  var temp = "" + ((hour > 12) ? hour - 12 : hour)
		  if(hour==0) temp = "12"
		  if(temp.length==1) temp = " " + temp
		  temp += ((minute < 10) ? ":0" : ":") + minute
		  temp += ((second < 10) ? ":0" : ":") + second
		  temp += (hour >= 12) ? " <span class='timeviewPM'>PM</span>" : " <span class='timeviewAM'>AM</span>"

    if (DomYes) {
  		var time1=document.getElementById('time5');
	} else {
		var time1=document.all['time5'];
	}
	time1.innerHTML=temp;
   setTimeout("clock5()",1000)
   }  
   
   
function clock6(){
	
		  var TimezoneOffset =-4; // adjust for time zone
		  var localTime = new Date()
		  var ms = localTime.getTime() 
					 + (localTime.getTimezoneOffset() * 60000)
					 + TimezoneOffset * 3600000
		  var time =  new Date(ms) 
		  var hour = time.getHours() 
		  var minute = time.getMinutes()
		  var second = time.getSeconds()
		  var temp = "" + ((hour > 12) ? hour - 12 : hour)
		  if(hour==0) temp = "12"
		  if(temp.length==1) temp = " " + temp
		  temp += ((minute < 10) ? ":0" : ":") + minute
		  temp += ((second < 10) ? ":0" : ":") + second
		  temp += (hour >= 12) ? " <span class='timeviewPM'>PM</span>" : " <span class='timeviewAM'>AM</span>"

    if (DomYes) {
  		var time1=document.getElementById('time6');
	} else {
		var time1=document.all['time6'];
	}
	time1.innerHTML=temp;
   setTimeout("clock6()",1000)
   }  

function initAllClocks()
{
	jsClockGMT();
	clockshangai();
	clock3();
	//clock4();
	clock5();
	clock6();
}

function changecolor(obj)
{
	 var randomnumber=Math.floor(Math.random()*7);
	 if(randomnumber < 8 && randomnumber>0)
	 obj.className="box"+randomnumber;
}

///////////////////////////////////////////////////////////////////////
////^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
////||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
///						FUNCTION FOR THE CLOCK DISPLAY IN THE BOTTOM OF THE PAGE
////END  HERE
///////////////////////////////////////////////////////////////////////

function frmcoindetcheck(frm)
{
	var cond=true;
	
	if(!isemtpyandlength(frm.txttitle,0,"Coin title cannot be Null") && cond==true )
	{
		cond=false;
	}
	else if(!isemtpyandlength(frm.txtdesc,0,"Coin Description cannot be Null") && cond==true )
	{
		cond=false;
	}
	
	
	if(cond==true)
	{
		frm.submit();
	}
	else
	{
		return false;
	}
}


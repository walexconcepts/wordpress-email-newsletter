// JavaScript Document
function customer()
{
	var cond=true;
	if(document.form.email.value.length==0)
	{
		alert("Please enter Email.");
		if(cond==true)
		{
			document.form.email.focus();
		}
		cond=false;
		return false;
	}else if(!checkMail(document.form.email.value))
	{
		alert("Email must contain an email address.\n");
		if(cond==true)
		{
			document.form.email.focus();
		}
		cond=false;
		return false;
	}
	
	if(document.form.fname.value.length==0)
	{
		//alert("Please Enter First Name.");
		alert("Please Enter Your Name.");
		if(cond==true)
		if(cond==true)
		{
			document.form.fname.focus();
		}
		cond=false;
		return false;
	}
	if(document.form.lname.value.length==0)
	{
		alert("Please Enter Last Name.");
		if(cond==true)
		{
			document.form.lname.focus();
		}
		cond=false;
		return false;
	}	
	if(document.form.password.value.length==0)
	{
		alert("Please Enter Password.");
		if(cond==true)
		{
			document.form.password.focus();
		}
		cond=false;
		return false;
	}
	if(document.form.password2.value.length==0)
	{
		alert("Please Enter Confirm Password.");
		if(cond==true)
		{
			document.form.password2.focus();
		}
		cond=false;
		return false;
	}
	if(document.form.birthdate.value.length==0)
	{
		alert("Please Enter Date of Birth.");
		if(cond==true)
		{
			document.form.birthdate.focus();
		}
		cond=false;
		return false;
	}
	if(document.form.phoneno.value.length==0)
	{
		alert("Please Enter Daytime Phone Number.");
		if(cond==true)
		{
			document.form.phoneno.focus();
		}
		cond=false;
		return false;
	}
	if(document.form.faxno.value.length==0)
	{
		alert("Please Enter Eveningtime Phone Number.");
		if(cond==true)
		{
			document.form.faxno.focus();
		}
		cond=false;
		return false;
	}
	if(document.form.houseno.value.length==0)
	{
		alert("Please enter House No.");
		if(cond==true)
		{
			document.form.houseno.focus();
		}
		cond=false;
		return false;
	}
	if(document.form.add1.value.length==0)
	{
		alert("Please enter Street Address.");
		if(cond==true)
		{
			document.form.add1.focus();
		}
		cond=false;
		return false;
	}
	if(document.form.city.value.length==0)
	{
		alert("Please enter City.");
		if(cond==true)
		{
			document.form.city.focus();
		}
		cond=false;
		return false;
	}
	if(document.form.state.value.length==0)
	{
		alert("Please Select State.");
		if(cond==true)
		{
			document.form.state.focus();
		}
		cond=false;
		return false;
	}
	if(document.form.slt.value.length==0)
	{
		alert("Please Select News Letter.");
		if(cond==true)
		{
			document.form.slt.focus();
		}
		cond=false;
		return false;
	}
	
	
	if(document.form.password.value != "" && document.form.password2.value != "" ) 
	{
		if(document.form.password.value == document.form.password2.value)
		{
			return true;
		}
		else
		{
			alert("Password and Confirm Password does not Match.");
			return false;
		}
	}
	
	if(!IsNumeric(document.form.phoneno.value))
	{
		alert("Please Enter Numeric value for Phone No.");
		if(condition==true)
		{
			document.form.phoneno.focus();
		}
		condition=false;
		return false;
			
	}
	
	
	var radiobutton;
	radiobutton="";
	
	// check validation for radiobuttn
	for (i=0; i<document.form.radiobutton.length; i++)
	{
		if (document.form.radiobutton[i].checked)
		{
			radio = document.form.radiobutton[i].value;
		}
	}
	if(radiobutton=="")
	{
		alert("Please Select your Sex.");
		return false;
	}
	
}	
function checkMail(email)
{
	var x = email;
	var filter  = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	if (filter.test(x)) 
	{
	 return true;
	}
	else 
	{
	  return false;
	}
}

//  only insert integer no in Age field.
function IsNumeric(sText)
{
   var ValidChars = "0123456789.";
   var IsNumber=true;
   var Char;

   for (i = 0; i < sText.length && IsNumber == true; i++) 
      { 
      Char = sText.charAt(i); 
      if (ValidChars.indexOf(Char) == -1) 
         {
         IsNumber = false;
         }
      }
   return IsNumber;
}


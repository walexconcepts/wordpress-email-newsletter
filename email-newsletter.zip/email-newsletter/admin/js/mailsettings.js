
 
// JavaScript Document
function mailsettings()
{
	var cond=true;
	if(document.form.url.value==0)
	{
		alert("Please Enter *Mailserver_Url.");
		if(cond==true)
		{
			document.form.url.focus();
		}
		cond=false;
		return false;
	}
	
	
	if(document.form.login.value.length==0)
	{
		alert("Please enter Mailserver_Login.");
		if(cond==true)
		{
			document.form.login.focus();
		}
		cond=false;
		return false;
	}else if(!checkMail(document.form.login.value))
	{
		alert("Mailserver_Login must contain an email address.\n");
		if(cond==true)
		{
			document.form.login.focus();
		}
		cond=false;
		return false;
	}
	
	
	
	if(document.form.password.value==0)
	{
		alert("Please Enter Password.");
		if(cond==true)
		{
			document.form.password.focus();
		}
		cond=false;
		return false;
	}
	if(document.form.port.value.length==0)
	{
		alert("Please Enter *Mailserver_Port.");
		if(cond==true)
		{
			document.form.port.focus();
		}
		cond=false;
		return false;
	}
	
	if(document.form.frontend.value == 0)
	{
		alert("Please select your frontend option.")
		if(cond==true)
		{
			document.form.frontend.focus();
		}
		cond=false;
		return false;
	}
	

	
}	
function checkMail(email)
{
	var x = email;
	var filter  = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	if (filter.test(x)) 
	{
	 return true;
	}
	else 
	{
	  return false;
	}
}



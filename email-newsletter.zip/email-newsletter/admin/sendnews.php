<?php
if ( ! defined( 'ABSPATH' ) ) exit; 

	
$page=sanitize_text_field($_REQUEST["page"]);
$current_url = esc_url(admin_url( "admin.php?page=".$page));



$sql = "select * from broadcasts_mailnewsletter";
$result = $wpdb->get_results($wpdb->prepare($sql));
if(count($result)>0){			
foreach($result as $row){
		$url = sanitize_text_field($row->url);	   
		$login = sanitize_text_field($row->login);
		$password = sanitize_text_field($row->password);
		$port = sanitize_text_field($row->port);
				
	}
}
if(isset($_REQUEST['Submit']) && ($_REQUEST['Submit'])=="Send_Mail"){	
$mailer = new PHPMailer(TRUE);  

$mailer->SMTPDebug = 0;       
$mailer->isSMTP();                           
$mailer->Host = $url;          
$mailer->SMTPAuth = true;                    
$mailer->Username = $login;       
$mailer->Password = $password;        
$mailer->SMTPSecure = 'tls';                  
$mailer->Port = $port; 		

$mailer->setFrom($login, 'izzumes'); 
$mailer->addReplyTo($login, 'izzumes'); 	

			
$email_id=sanitize_text_field($_REQUEST['newsletter']);
	

$os = array();
$sql12="select * from broadcasts_newslettersent Where intid = '$email_id'";
$resultb = $wpdb->get_results($wpdb->prepare($sql12));
//if(count($resultb)>0){	
foreach($resultb as $row){			
	$os[] = sanitize_text_field($row->varcustemail);							
	}		
//}		
$sql="select * from broadcasts_newsletters where intid='$email_id'";
$resultc = $wpdb->get_results($wpdb->prepare($sql));
if($resultc) {
	foreach($resultc as $res){
		$sub= sanitize_text_field($res->varsubject);
		$allowed_html = email_newsletter_broadcasts_allowed_html();
		$mess= wp_kses($res->vartext, $allowed_html);
	}	
}
if(isset($_REQUEST['all']) && ($_REQUEST['all'])!="") {
		$sql12="select * from broadcasts_customers where intnewsletter='1'";
		$resultv = $wpdb->get_results($wpdb->prepare($sql12));
		if(count($resultv)>0){
		foreach($resultv as $resman12){
			$varcustemail= sanitize_text_field($resman12->varcustemail);
			
			if (!in_array($varcustemail, $os)) {	

			// Add a recipient 
			$mailer->addAddress($varcustemail); 
			
			$mailer->isHTML(true); 
			$mailer->Subject = $sub; 
			// Mail body content 
			$bodyContent = '<h1>'.$sub.'</h1>'; 
			$bodyContent .= '<p>'.$mess.'</p>';
			
			
			$mailer->Body    = $bodyContent; 
			
			$sentmail = $mailer->send(); 
				if ($sentmail){
				$result=$wpdb->query( $wpdb->prepare( "INSERT INTO broadcasts_newslettersent (`intid` , `varcustemail` , `subject` ,`status`) VALUES ( %d, %s, %s, %s)", $email_id, $varcustemail, $sub, 'Not read') );

				}
			}
		}
		}
} 
if ($result){
	header("location:$current_url&msg=newsent");
}else if (in_array($to, $os)) {
 header("location:$current_url&msg=emhrgs");
} else {
    header("location:$current_url&msg=errn");
}
die();

}

?>
<style>
table, td {
		width:60%;
        border: 1px solid black;
        border-collapse: collapse;
        padding: 25px;
}
</style>

 <br /> <br />

<div style="float:none" id="main" class="#well center-block-7 #col-md-4-3">
  
	<form name="form" method="post" action="" enctype="multipart/form-data">
	<table align="center">
    <tr>
	<td colspan="3" align="left">
	<?php if($_REQUEST['msg']){?>
	<h3 style="color:red"><?php echo esc_html($mess[$_REQUEST['msg']]); ?>
	</h3> 
	<?php } else {?>
	<h3>Send Newsletter...
	</h3>
	<?php } ?>
	</td>
	</tr> 
    				
	
	
	<tr>
	<td colspan="1" align="center">
		<input class ="test3" name="all" type="checkbox" id="all" value="1" />
       Send to All
		</td>
    <td colspan="2" align="right">
    
	<select style="#width:100%;#max-width:100%" required name="newsletter" id="newsletter">
    <option value="0" disabled selected>Select Newsletter Subject</option>
    <?php 
	$sql2="select * from broadcasts_newsletters";
	$resultm = $wpdb->get_results($wpdb->prepare($sql2));
	if(count($resultm)>0){
        foreach($resultm as $resman2){			
		?>
        <option value="<?php echo esc_html($resman2->intid);?>" >
        <?php echo esc_html($resman2->varsubject);?></option>
		<?php					
		}
		
	 }
    ?>
    </select>
    </td>
    </tr>
	
	 
	<tr>
		<td align="center"><strong>Date Register</strong></td>
		<td align="center"><strong>Name</strong></td>
		<td align="center"><strong>Email</strong></td>
	</tr>
	
	
	<?php
	$query = $wpdb->get_results($wpdb->prepare("SELECT COUNT(*) as num FROM broadcasts_customers"));
	foreach($query as $row)	{
	$total_pages = $row->num;
	}
	$targetpage = $current_url;
	$limit = 2;
	$page = (isset($_GET['paged'])) ? (int)sanitize_text_field($_GET['paged']) : 0;
	if($page) 
	$start = ($page - 1) * $limit; 			
	else
	$start = 0;

	$resultb = $wpdb->get_results($wpdb->prepare("SELECT * FROM broadcasts_customers where intnewsletter='1' order by `intcusid` desc LIMIT $start, %d", $limit ));

	if(count($resultb)>0){
	foreach($resultb as $row){
      $cusid=sanitize_text_field($row->intcusid);
	  $dtregtime=sanitize_text_field($row->dtregtime);
	  
	  $email=sanitize_text_field($row->varcustemail);
      $name=sanitize_text_field($row->varcustfname);	  
	?>
     <tr>
	 <td align="center"><?php echo esc_html($dtregtime); ?></td>
	 <td align="center"><?php echo esc_html($name); ?></td>
     <td align="center"><?php echo esc_html($email); ?></td>
     
     </tr>
    <?php
      }
    }
    ?>
	
 <tr>
  <td colspan="3" align="right">
  <input name="Submit" type="submit" class="btn" value="Send_Mail"  onClick="return sendemail();">
  <input name="sendmail" type="hidden" id="sendmail" />
  </td>
 </tr>
 
 <tr>  
	<td colspan="4">
	<div class="pagination">
        <div class="results">
        <?php
		$adjacents = 1;
		if ($page == 0) $page = 1;					
		$prev = $page - 1;							
		$next = $page + 1;							
		$lastpage = ceil($total_pages/$limit);		
		$lpm1 = $lastpage - 1;						
		$pagination = "";
		if($lastpage > 1)
		{	
			$pagination .= "<div class=\"pagination\">";
			if ($page > 1) 
				$pagination.= "<a href=\"$targetpage&paged=$prev\">&laquo; previous</a>";
			else
				$pagination.= "<span class=\"disabled\">&laquo; previous</span>";	
				
			if ($lastpage < 7 + ($adjacents * 2))	
			{	
				for ($counter = 1; $counter <= $lastpage; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage&paged=$counter\">$counter</a>";					
				}
			}
			elseif($lastpage > 5 + ($adjacents * 2))	
			{
				
				if($page < 1 + ($adjacents * 2))		
				{
					for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
					{
						if ($counter == $page)
							$pagination.= "<span class=\"current\">$counter</span>";
						else
							$pagination.= "<a href=\"$targetpage&paged=$counter\">$counter</a>";					
					}
					$pagination .= "<span class=\"elipses\">...</span>";
					$pagination.= "<a href=\"$targetpage&paged=$lpm1\">$lpm1</a>";
					$pagination.= "<a href=\"$targetpage&paged=$lastpage\">$lastpage</a>";		
				}
				
				elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
				{
					$pagination.= "<a href=\"$targetpage&paged=1\">1</a>";
					$pagination.= "<a href=\"$targetpage&paged=2\">2</a>";
					$pagination .= "<span class=\"elipses\">...</span>";
					for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
					{
						if ($counter == $page)
							$pagination.= "<span class=\"current\">$counter</span>";
						else
							$pagination.= "<a href=\"$targetpage&paged=$counter\">$counter</a>";					
					}
					$pagination .= "<span class=\"elipses\">...</span>";
					$pagination.= "<a href=\"$targetpage&paged=$lpm1\">$lpm1</a>";
					$pagination.= "<a href=\"$targetpage&paged=$lastpage\">$lastpage</a>";		
				}
				
				else
				{
					$pagination.= "<a href=\"$targetpage&paged=1\">1</a>";
					$pagination.= "<a href=\"$targetpage&paged=2\">2</a>";
					$pagination .= "<span class=\"elipses\">...</span>";
					for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
					{
						if ($counter == $page)
							$pagination.= "<span class=\"current\">$counter</span>";
						else
							$pagination.= "<a href=\"$targetpage&paged=$counter\">$counter</a>";					
					}
				}
			}
			
			if ($page < $counter - 1) 
				$pagination.= "<a href=\"$targetpage&paged=$next\">next &raquo;</a>";
			else
				$pagination.= "<span class=\"disabled\">next &raquo;</span>";
			$pagination.= "</div>\n";		
		}
	?>

            <?php 
	       //print $pagination;
           $allowed_html = email_newsletter_broadcasts_allowed_html();
			echo wp_kses($pagination, $allowed_html);			 
?>
        </div>
    </div>
	</td>
	</tr>
</table>
</form>	

</div>



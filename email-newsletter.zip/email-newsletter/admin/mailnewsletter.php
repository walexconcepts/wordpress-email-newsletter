<?php
if ( ! defined( 'ABSPATH' ) ) exit; 
$page=sanitize_text_field($_REQUEST["page"]);
$current_url = esc_url(admin_url( "admin.php?page=".$page));

$frontended=sanitize_text_field($_REQUEST['frontend']);


define('EMAIL_NEWSLETTER_BROADCASTS_PATH', __FILE__ . '/'); 
$installpath = explode('plugins', EMAIL_NEWSLETTER_BROADCASTS_PATH);
define('EMAIL_NEWSLETTER_BROADCASTS_INSTALLATION_PATH', dirname($installpath[0]) . '/');  
require_once( EMAIL_NEWSLETTER_BROADCASTS_INSTALLATION_PATH . 'wp-includes/pluggable.php' );

$nonce = sanitize_text_field($_REQUEST['_wpnonce']);


if(isset($_REQUEST['Submit']) && trim($_REQUEST['Submit']) == "Update" && wp_verify_nonce( $nonce, 'submit_mailsettings' ))	{
//if(isset($_REQUEST['Submit'])) 	{
$url=sanitize_text_field($_REQUEST['url']);
$login=sanitize_text_field($_REQUEST['login']);
$password=sanitize_text_field($_REQUEST['password']);
$port=sanitize_text_field($_REQUEST['port']);
$frontend=sanitize_text_field($_REQUEST['frontend']);


$result = $wpdb->query($wpdb->prepare( "UPDATE broadcasts_mailnewsletter SET  
url = %s,
login = %s,
password = %s,
port = %d,
frontend = %s", $url, $login, $password, $port, $frontend ));
if ($result){
header("location:$current_url&msg=edit");
}
}		

$url = "";
$login = "";
$password = "";
$port = "";
$action=1;		
$result = $wpdb->get_results($wpdb->prepare("SELECT * FROM broadcasts_mailnewsletter" ));
if($result)	{
foreach($result as $row)	{			
$url = sanitize_text_field($row->url);
$login = sanitize_text_field($row->login);
$password = sanitize_text_field($row->password);
$port = sanitize_text_field($row->port);
$frontend = sanitize_text_field($row->frontend);
}
}			
?>


 
<br /> 
<br /> 


<div style="float:none" id="main" class="well form-container center-block col-md-7">
<form name="form" method="post" action="" enctype="multipart/form-data">
<div class="form-group col-md-12">
<?php
		
		if(isset($_REQUEST['msg'])) {?>
		<h2 style="color:red"><?php echo esc_html($mess[$_REQUEST['msg']]); ?>
		</h2> 
		<?php } else { ?>
		<h2>Newsletter Mail Settings......
		</h2>
		<?php } ?>																                                                                                                                     


</div>
<div class="form-group col-md-12">
<div class="controls">
<label>*Mailserver_Url</label><br>
<input style="width:100%;max-width:100%" placeholder="e.g mail.example.com" name="url" type="text" id="url" value="<?php echo esc_html($url);?>" /></div>
</div>

<div  class="form-group col-md-12">
<div class="controls">
<label>*Mailserver_Login</label><br>
<input style="width:100%;max-width:100%" placeholder="e.g login@example.com" name="login" type="text" id="login" value="<?php echo esc_html($login);?>" /></div>
</div>



<div  class="form-group col-md-12">
<div class="controls">
<label>*Mailserver_Password</label><br>
<input style="width:100%;max-width:100%" placeholder="e.g password" name="password" type="text" id="password" value="<?php echo esc_html($password);?>" /></div>
</div>




<div  class="form-group col-md-12">
<div class="controls">
<label>*Mailserver_Port</label><br>
<input style="width:100%;max-width:100%" placeholder="e.g 110" name="port" type="text" id="port" value="<?php echo esc_html($port);?>" />
</div>
</div>



<div  class="form-group col-md-12">
<div class="controls">
<label>*Frontend form:</label><br>
<select style="width:100%;max-width:100%" required id="frontend" name="frontend">
					<option value="0" disabled selected>Select your option</option>
					<option value="htmlbox"<?php if(isset($_POST['frontend']) == "htmlbox") echo "selected";?>>htmlbox block form </option>
				</select></div>
</div>


<div style="clear:both"><br></div>

<div class="form-group col-md-12">
<div class="controls">
<input name="Submit" type="submit" class="btn" id="submit" value="Update" onClick="return mailsettings();"/></td>
</div>
</div>

<?php wp_nonce_field( 'submit_mailsettings' ); ?>
</form>

<div style="clear:both"><br></div>

</div>
    
  



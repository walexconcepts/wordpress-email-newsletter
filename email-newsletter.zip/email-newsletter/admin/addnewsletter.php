<?php
if ( ! defined( 'ABSPATH' ) ) exit; 
 
$page=sanitize_text_field($_REQUEST["page"]);
$current_url = esc_url(admin_url( "admin.php?page=".$page));

$page2="newsmanager_newsletter";
$current_url2 = esc_url(admin_url( "admin.php?page=".$page2));


$nonce = sanitize_text_field($_REQUEST['_wpnonce']);

// INSERT into database.
if(isset($_REQUEST['Submit']) && trim($_REQUEST['Submit']) == "Submit" && wp_verify_nonce( $nonce, 'submit_newsletter' )){		
$error = array();
if (empty($_REQUEST['varsubject'])){ 
	$error[]= 'Please Enter Subject.';
	
}else{			
	$varsubject=sanitize_text_field($_REQUEST['varsubject']);
}	
if (empty($_REQUEST['vartext'])){
    $error[]= 'Please Enter Text Message.';
}else{
	$allowed_html = email_newsletter_broadcasts_allowed_html();
    $vartext= wp_kses($_REQUEST['vartext'], $allowed_html);
}				
if (empty($error)){	
			$sql=$wpdb->query( $wpdb->prepare( "INSERT INTO broadcasts_newsletters (varsubject, vartext) VALUES ( %s, %s)", $varsubject, $vartext) );
			if ($sql){
			header("location:$current_url2&msg=add");
			die();
			}		
}			
}

?>



<br />
<br />    
<div style="float:none" id="main" class="well form-container center-block col-md-7">

<form name="newsletter" action="" method="post" enctype="multipart/form-data">


<div class="form-group col-md-12">
<?php
if (!empty($error)){ ?>
<?php 
foreach ($error as $msg) { 
$varsubject1=sanitize_text_field($_REQUEST['varsubject']);
$allowed_html = email_newsletter_broadcasts_allowed_html();
$vartext1= wp_kses($_REQUEST['vartext'], $allowed_html);
?>
<h3 style="color:red"><?php echo esc_html(" &#8727; $msg"); ?>
</h3>
<?php 
} 
?>
<?php } else {?>
<h3>Add New NewsLetter...
</h3>
<?php } ?>
</div>




<div class="form-group col-md-12">
<div class="controls">
<label>*Subject :</label><br>
<input style="width:100%" name="varsubject" type="text" id="varsubject" value="<?php echo esc_html($varsubject1);?>" >
<div style="clear:both"></div>
</div>
</div>



<div class="form-group #col-md-12">
<div class="controls">
<label>*Message :</label><br>
<textarea style="min-width:100%" name="vartext" rows="40" id="vartext">
<?php
$allowed_html = email_newsletter_broadcasts_allowed_html();
echo wp_kses($vartext1, $allowed_html);	
?>
<?php #echo esc_html($vartext1);?>
</textarea>
</div>
</div>

<div style="clear:both"><br></div>

<div class="form-group col-md-12">
<div class="controls">
<input name="Submit" type="submit" class="btn" value="<?php echo ($action==2) ? "Update":"Submit"; ?>"  onClick="return newsletter();">
</div>
</div>

<?php wp_nonce_field( 'submit_newsletter' ); ?>
</form>
<?php echo esc_html(email_newsletter_broadcasts_editor()); ?> 
<div style="clear:both"><br></div>                                       
                        
</div>


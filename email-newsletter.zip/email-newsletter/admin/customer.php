<?php
if ( ! defined( 'ABSPATH' ) ) exit; 
 
$page=sanitize_text_field($_REQUEST["page"]);
$current_url = esc_url(admin_url( "admin.php?page=".$page));


	
// DELETE record from database
if(isset($_REQUEST['a']) && trim($_REQUEST['a'])==3){
	if(isset($_REQUEST['intcusid']) && trim($_REQUEST['intcusid']!="")){		
		$screen_id =  sanitize_text_field($_REQUEST['intcusid']);
		
		$email =  sanitize_text_field($_REQUEST['cusemail']);
		
		$sql_del = $wpdb->prepare( 'DELETE FROM broadcasts_customers WHERE intcusid = %d', $screen_id );
        $delete = $wpdb->query( $sql_del );
		
		$sql_del = $wpdb->prepare( 'Delete from broadcasts_newslettersent where varcustemail = %s', $email );
        $delete = $wpdb->query( $sql_del );
		header("location:$current_url&msg=del");
		die();
	}
}



?>
<style>
table, td {
		width:60%;
        border: 1px solid black;
        border-collapse: collapse;
        padding: 25px;
}
</style>





<br />
<br />  



<table align="center">
<tr>
<td colspan="4" align="left">
<h3>Subscribers......
</h3>															                                                                                                                     
</td>
</tr>  




<tr>
<td colspan="6" align="right" class="form-container ">
<form method="post" action="">
<div class="controls"> 
<input style="width:40%" placeholder="Search By Email:" action="page.php" name="search" type="text" id="search" />
<input style="width:10%" name="Submit2" type="submit" class="btn" value="Go" />
</form>
</div>
</td>
</tr>



<tr>
<td align="center"><strong>Name</strong></td>
<td align="center"><strong>Email</strong></td>
<td align="center"><strong>Register Date</strong></td>
<td align="center"><strong>Delete</strong></td>
</tr>

<?php
$query = $wpdb->get_results($wpdb->prepare("SELECT COUNT(*) as num FROM broadcasts_customers"));
foreach($query as $row)	{
$total_pages = sanitize_text_field($row->num);
}
$targetpage = $current_url;
$limit = 2;
$page = (isset($_GET['paged'])) ? (int)sanitize_text_field($_GET['paged']) : 0;
if($page) 
$start = ($page - 1) * $limit; 			
else
$start = 0;

if(isset($_REQUEST['search']) && ($_REQUEST['search'])!=""){
$search = sanitize_text_field($_REQUEST['search']);
$sql_select = "select *	from broadcasts_customers WHERE `varcustemail` LIKE '%".$search."%' LIMIT %d, %d";


}else{
$sql_select = "select * from  broadcasts_customers order by `intcusid` desc LIMIT %d, %d";

}



$resultm = $wpdb->get_results($wpdb->prepare($sql_select, $start, $limit));
if(count($resultm)>0){
$color="1";
foreach($resultm as $sql){	
$screen_id=sanitize_text_field($sql->intcusid);
$email=sanitize_text_field($sql->varcustemail);
$name=sanitize_text_field($sql->varcustfname);
$regtime=sanitize_text_field($sql->dtregtime);
if($color==1){
?>

<tr bgcolor='#FFC600'>
<td align="center"><?php echo esc_html($name);?></td>
<td align="center"><?php echo esc_html($email);?></td>
<td align="center"><?php echo esc_html($regtime);?></td>
<td align="center"><a Title="Click here to Delete" class="link"
href="<?php echo esc_html($current_url); ?>&a=3&intcusid=<?php echo esc_html($screen_id);?>&cusemail=<?php echo esc_html($email);?>"
onClick="return confirm('Are you sure to delete this record ?');">
<img src="<?php echo esc_url(plugin_dir_url( __FILE__ ) . 'images/delete.bmp'); ?>" alt="Delete" border="0">
</a>
</td>
</tr>
<?php $color="2";} else { ?>
<tr bgcolor='#C6FF00' align="center">
<td align="center"><?php echo esc_html($name);?></td>
<td align="center"><?php echo esc_html($email);?></td>
<td align="center"><?php echo esc_html($regtime);?></td>
<td align="center"><a Title="Click here to Delete" href="<?php echo esc_html($current_url); ?>&a=3&intcusid=<?php echo esc_html($screen_id);?>&cusemail=<?php echo esc_html($email);?>"
onClick="return confirm('Are you sure to delete this record ?');">
<img src="<?php echo esc_url(plugin_dir_url( __FILE__ ) . 'images/delete.bmp'); ?>" alt="Delete" border="0">
</a>
</td>
</tr>
<?php $color="1";}  ?>
<?php
}
?>


<tr>     
<td colspan="4" align="left">
<div class="pagination">
        <div class="results">
            <?php
$adjacents = 1;
		if ($page == 0) $page = 1;					
		$prev = $page - 1;							
		$next = $page + 1;							
		$lastpage = ceil($total_pages/$limit);		
		$lpm1 = $lastpage - 1;						
		$pagination = "";
		if($lastpage > 1)
		{	
			$pagination .= "<div class=\"pagination\">";
			if ($page > 1) 
				$pagination.= "<a href=\"$targetpage&paged=$prev\">&laquo; previous</a>";
			else
				$pagination.= "<span class=\"disabled\">&laquo; previous</span>";	
				
			if ($lastpage < 7 + ($adjacents * 2))	
			{	
				for ($counter = 1; $counter <= $lastpage; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage&paged=$counter\">$counter</a>";					
				}
			}
			elseif($lastpage > 5 + ($adjacents * 2))	
			{
				
				if($page < 1 + ($adjacents * 2))		
				{
					for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
					{
						if ($counter == $page)
							$pagination.= "<span class=\"current\">$counter</span>";
						else
							$pagination.= "<a href=\"$targetpage&paged=$counter\">$counter</a>";					
					}
					$pagination .= "<span class=\"elipses\">...</span>";
					$pagination.= "<a href=\"$targetpage&paged=$lpm1\">$lpm1</a>";
					$pagination.= "<a href=\"$targetpage&paged=$lastpage\">$lastpage</a>";		
				}
				
				elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
				{
					$pagination.= "<a href=\"$targetpage&paged=1\">1</a>";
					$pagination.= "<a href=\"$targetpage&paged=2\">2</a>";
					$pagination .= "<span class=\"elipses\">...</span>";
					for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
					{
						if ($counter == $page)
							$pagination.= "<span class=\"current\">$counter</span>";
						else
							$pagination.= "<a href=\"$targetpage&paged=$counter\">$counter</a>";					
					}
					$pagination .= "<span class=\"elipses\">...</span>";
					$pagination.= "<a href=\"$targetpage&paged=$lpm1\">$lpm1</a>";
					$pagination.= "<a href=\"$targetpage&paged=$lastpage\">$lastpage</a>";		
				}
				
				else
				{
					$pagination.= "<a href=\"$targetpage&paged=1\">1</a>";
					$pagination.= "<a href=\"$targetpage&paged=2\">2</a>";
					$pagination .= "<span class=\"elipses\">...</span>";
					for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
					{
						if ($counter == $page)
							$pagination.= "<span class=\"current\">$counter</span>";
						else
							$pagination.= "<a href=\"$targetpage&paged=$counter\">$counter</a>";					
					}
				}
			}
			
			if ($page < $counter - 1) 
				$pagination.= "<a href=\"$targetpage&paged=$next\">next &raquo;</a>";
			else
				$pagination.= "<span class=\"disabled\">next &raquo;</span>";
			$pagination.= "</div>\n";		
		}
	?>

            <?php 
            $allowed_html = email_newsletter_broadcasts_allowed_html();
			echo wp_kses($pagination, $allowed_html);			
?>
        </div>
    </div>
</td>
</tr>
 <?php
	}	
   ?>
</table>
                                    




                        





<?php
if ( ! defined( 'ABSPATH' ) ) exit; 
 
$page=sanitize_text_field($_REQUEST["page"]);
$current_url = esc_url(admin_url( "admin.php?page=".$page));



// DELETE record from database
if(isset($_REQUEST['a']) && trim($_REQUEST['a'])==3) {
	if(isset($_REQUEST['intid']) && trim($_REQUEST['intid']!=""))
	{	
        $screen_id =  $_REQUEST['intid'];
		$sql_del = $wpdb->prepare( 'DELETE FROM broadcasts_newsletters WHERE intid = %d', $screen_id );
        $delete1 = $wpdb->query( $sql_del );
		if($delete1){
		$screen_id =  sanitize_text_field($_REQUEST['intid']);
		$sql_del = $wpdb->prepare( 'DELETE FROM broadcasts_newslettersent WHERE intid = %d', $screen_id );
		$delete2 = $wpdb->query( $sql_del );
		
		header("location:$current_url&msg=del");
		die();
		}
		
	}
}



?>
<style>
table, td {
		width:60%;
        border: 1px solid black;
        border-collapse: collapse;
        padding: 25px;
}
</style>


    
  
   
<br />
<br />   


                                        
<table align="center">
<tr>
<td colspan="3" align="left">
<?php
if(isset($_REQUEST['msg'])) {?>
<h3 style="color:red"><?php echo esc_html($mess[$_REQUEST['msg']]); ?>
<a href="<?php echo esc_url(admin_url('admin.php?page=addnews_newsletter'));?>" class="aa">[NEW]</a>
</h3> 
<?php } else { ?>
<h3>News Manager...
<a href="<?php echo esc_url(admin_url('admin.php?page=addnews_newsletter'));?>" class="aa">[NEW]</a>
</h3>
<?php } ?>																                                                                                                                     
</td>
</tr>


 
 <tr>
		<td align="center"><strong>Subject</strong></td>
        <td align="center"><strong>Description</strong></td>
        
        <td align="center"><strong>Delete</strong></td>
        
        
</tr>
<?php
//$query = $wpdb->get_results($wpdb->prepare("SELECT COUNT(*) as num FROM broadcasts_customers"));
$query = $wpdb->get_results($wpdb->prepare("SELECT COUNT(*) as num FROM broadcasts_newsletters"));

foreach($query as $row)	{
$total_pages = sanitize_text_field($row->num);
}
$targetpage = $current_url;
$limit = 2;
$page = (isset($_GET['paged'])) ? (int)sanitize_text_field($_GET['paged']) : 0;
if($page) 
$start = ($page - 1) * $limit; 			
else
$start = 0;
//count subscriber";
$subscriber = $wpdb->get_results($wpdb->prepare("select * from  broadcasts_customers"));
$subscribernumber = count($subscriber);


//show all details";
$resultm = $wpdb->get_results($wpdb->prepare("select * from broadcasts_newsletters order by `intid` desc LIMIT %d, %d", $start, $limit ));
//if($resultm){
if(count($resultm)>0){
$color="1";
$pgno = $page_no*$row_per_page;
foreach($resultm as $row)	{
$screen_id=sanitize_text_field($row->intid);
$subject=sanitize_text_field($row->varsubject);
$pgno=$pgno+1;
//$sent = $wpdb->get_results($wpdb->prepare("select * from broadcasts_newslettersent Where intid = '$screen_id'"));	
$sent = $wpdb->get_results($wpdb->prepare('select * from broadcasts_newslettersent Where intid = %d', $screen_id));
$sentnumber = count($sent);
	
if($color==1){
?>
<tr bgcolor='#FFC600' align="center">                                                       
<!--td><!?php echo $pgno; ?>.</td-->
<td><?php echo $subject; ?></td>
<td>
<?php echo $sentnumber; ?> sent / <?php echo $subscribernumber; ?> subscriber
</td>

<td>
<a Title="Click here to Delete" href="<?php echo esc_html($current_url); ?>&a=3&intid=<?php echo $screen_id;?>"
onClick="return confirm('Are you sure to delete this record ?');">
<img src="<?php echo esc_url(plugin_dir_url( __FILE__ ) . 'images/delete.bmp'); ?>" alt="Delete" border="0">
</a>
</td>
</tr>
<?php $color="2";} else { ?>
<tr bgcolor='#C6FF00' align="center">
<!--td><!?php echo $pgno; ?>.</td-->
<td><?php echo esc_html($subject); ?></td>
<td>
<?php echo esc_html($sentnumber); ?> sent / <?php echo esc_html($subscribernumber); ?> subscriber
</td>

<td>
<a Title="Click here to Delete" class="link" href="<?php echo esc_html($current_url); ?>&a=3&intid=<?php echo $screen_id;?>"
onClick="return confirm('Are you sure to delete this record ?');">
<img src="<?php echo esc_url(plugin_dir_url( __FILE__ ) . 'images/delete.bmp'); ?>" alt="Delete" border="0">
</a>
</td>
</tr>
<?php $color="1";}  ?>																							
<?php 
}
?>
<tr>  
<td colspan="3">
<div align="left">
<div class="pagination">
        <div class="results">
            <?php
$adjacents = 1;
		if ($page == 0) $page = 1;					
		$prev = $page - 1;							
		$next = $page + 1;							
		$lastpage = ceil($total_pages/$limit);		
		$lpm1 = $lastpage - 1;						
		$pagination = "";
		if($lastpage > 1)
		{	
			$pagination .= "<div class=\"pagination\">";
			if ($page > 1) 
				$pagination.= "<a href=\"$targetpage&paged=$prev\">&laquo; previous</a>";
			else
				$pagination.= "<span class=\"disabled\">&laquo; previous</span>";	
				
			if ($lastpage < 7 + ($adjacents * 2))	
			{	
				for ($counter = 1; $counter <= $lastpage; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage&paged=$counter\">$counter</a>";					
				}
			}
			elseif($lastpage > 5 + ($adjacents * 2))	
			{
				
				if($page < 1 + ($adjacents * 2))		
				{
					for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
					{
						if ($counter == $page)
							$pagination.= "<span class=\"current\">$counter</span>";
						else
							$pagination.= "<a href=\"$targetpage&paged=$counter\">$counter</a>";					
					}
					$pagination .= "<span class=\"elipses\">...</span>";
					$pagination.= "<a href=\"$targetpage&paged=$lpm1\">$lpm1</a>";
					$pagination.= "<a href=\"$targetpage&paged=$lastpage\">$lastpage</a>";		
				}
				
				elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
				{
					$pagination.= "<a href=\"$targetpage&paged=1\">1</a>";
					$pagination.= "<a href=\"$targetpage&paged=2\">2</a>";
					$pagination .= "<span class=\"elipses\">...</span>";
					for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
					{
						if ($counter == $page)
							$pagination.= "<span class=\"current\">$counter</span>";
						else
							$pagination.= "<a href=\"$targetpage&paged=$counter\">$counter</a>";					
					}
					$pagination .= "<span class=\"elipses\">...</span>";
					$pagination.= "<a href=\"$targetpage&paged=$lpm1\">$lpm1</a>";
					$pagination.= "<a href=\"$targetpage&paged=$lastpage\">$lastpage</a>";		
				}
				
				else
				{
					$pagination.= "<a href=\"$targetpage&paged=1\">1</a>";
					$pagination.= "<a href=\"$targetpage&paged=2\">2</a>";
					$pagination .= "<span class=\"elipses\">...</span>";
					for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
					{
						if ($counter == $page)
							$pagination.= "<span class=\"current\">$counter</span>";
						else
							$pagination.= "<a href=\"$targetpage&paged=$counter\">$counter</a>";					
					}
				}
			}
			
			if ($page < $counter - 1) 
				$pagination.= "<a href=\"$targetpage&paged=$next\">next &raquo;</a>";
			else
				$pagination.= "<span class=\"disabled\">next &raquo;</span>";
			$pagination.= "</div>\n";		
		}
	?>

            <?php 
	        //print $pagination;
            $allowed_html = email_newsletter_broadcasts_allowed_html();
			echo wp_kses($pagination, $allowed_html);		
?>
        </div>
    </div>
</div>
</td>
</tr>
   <?php
	}	
   ?>
                                                
                                
</table>

                        
	
	
	
	
	



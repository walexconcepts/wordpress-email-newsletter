===Email Subscribers & Newsletters Broadcasts===
Contributors: Adewale Emmanuel Awodeyi
Tags: email, subscriber, 
Requires at least: 5.4
Tested up to: 6.5
Stable tag: 1.0
Requires PHP: 5.6 or later
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Email Subscribers & Newsletters Broadcasts help you achieve all your newsletter related tasks effectively in one single place.


== Description ==
Email Subscribers & Newsletters Broadcasts helps you achieve all your newsletter related tasks effectively in 
one single place. Please visit [demo](https://walexconcepts.com/wordpress/plugin-demo/).



Free Version features:
<p>
<ul>
<li>* NO cron job and no scheduling</li>
<li>* Easily collect emails by adding a subscription form to your page using shortcode or php code</li>
<li>* HTML editor to compose newsletters.</li>
<li>* Send beautifully crafted HTML newsletters to your subscribers instantly</li>
<li>* Send newsletters using (simple mail transfer protocol) SMTp</li>
<li>* Send email to all users.</li>
<li>* Html block form subscription form at frontend.</li>
</ul>
</p>

Premium Features:
<p>
<ul>
<li>* All of te above free version features. </li>
<li>* Preview newsletter before sending email to users.</li>
<li>* Check email status when it was viewed so called tracking.</li>
<li>* Unsubscribe link in the mail.
<li>* Send email to all or specific users.</li>
<li>* Template for Woocommerce latest products while sending a newsletter.
<li>* Three different options to display subscription form at frontend.</li>
</ul>
</p>


== Installation at frontend ==

Put ShortCode /*if ( shortcode_exists( 'email_newsletter_broadcasts' ) ) { echo do_shortcode('[email_newsletter_broadcasts]');} */ to 
add Email Subscribers & Newsletters Broadcasts to the page. Please always remember to remove [/* */] from the Shortcode.




== Installation at backend ==

### Automatic installation ###

With automatic installation WordPress handles the file transfers so it is the easiest option and you can do it from your 
WordPress dashboard. Just navigate to the Plugins menu and click Add New. In the search field type "Awodeyi" to find 
the plugin. When it appears in a search results, use "Install now" button. When it is installed, activate it and plugin
is ready to use.

### Manual installation ###

1. Using FTP, upload entire `wsb-brands` folder to your site's `/wp-content/plugins/` directory. If you have downloaded 
a zip file, then you can also use the *Add new* option in the *Plugins* menu in WordPress and upload it and install in a
few clicks.  
2. Activate the plugin from the *Plugins* menu in WordPress and you are ready to go.



== Frequently Asked Questions ==
= Does Email Subscribers & Newsletters Broadcasts work with any Wordpress theme? =

Yes, it does. You can use it with any Wordpress theme.


= Do I get free support for this free plugin? = 
Yes, we can provide support via email and chat if needed. 


== Screenshots ==
<p>
<ul>
<li>1. screenshoot-1 Create newsletter to send</li>
<li>2. screenshoot-2 Create newsletter customer backend form</li>
<li>3. screenshoot-3 Manage newsletter </li>
<li>4. screenshoot-4 Newsletter details or preview</li>
<li>5. screenshoot-5 Newsletter subscriber manager</li>
<li>6. screenshoot-6 Newsletter mail settings</li>
<li>7. screenshoot-7 Send newsletter</li>
<li>8. screenshoot-8 Unsubscribe notification</li>
<li>9. screenshoot-9 Sample template</li>
<li>10. screenshoot-10 woocommerce template</li>
<li>11. screenshoot-11 Html block form</li>
<li>11. screenshoot-12 Optinbox button popup form</li>
<li>11. screenshoot-13 Scrollbox popup form</li>
</ul>
</p>




== Changelog ==
<p>
<ul>
= 1.0.0 =
<li>* Initial release of the plugin, June, 14, 2023.</li>
</ul>
</p>

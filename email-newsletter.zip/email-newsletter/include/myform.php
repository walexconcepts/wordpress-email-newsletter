
<div style="float:none" class="well center-block col-md-4">
                <div class="success_msg_displlay" style="display: none">Record added Successfully</div>
				
                <div class="error_msg_displlay" style="display: none">Email already exist.</div>
                
				<form action="" name="newsletterform" id="newsletterform" enctype="multipart/form-data">
							
                <div  style="margin-top: 0px; margin-bottom:0px;" class="center">                
				<h2 style="font-family:Agency fb;font-size: 25px;margin-top:">Subscribe to our mailing list to get the latest listings, updates and special offers delivered directly in your inbox.</h2>
           
				</div> 
                                    
				<label class="name"></label>
				<input style="width:100%" type="text" id="name" name="name" placeholder="Name:" value=""   />
							
                <label class="email"></label>
				<input style="width:100%" type="text" id="email" name="email" placeholder="E-mail:" value=""  />
							
				<div style="clear:both"><br></div>
				
				<button class="#btn-primary text-right" type='reset' value=''>Clear</button>
				<button class="#btn-primary text-right" type='button' id='submited' name='submited' value=''>Subscribe</button>
								
				<div style="clear:both"></div>		  
				</form>
			
				</div>


<script type="text/javascript">
jQuery(document).ready(function($) {   
$("#submited").click(function(){
if(document.newsletterform.name.value.length==0){
alert("Please enter your full name.");
}else if(document.newsletterform.email.value.length==0){
alert("Please enter your e-mail address.");
}else if(!checkMail(document.newsletterform.email.value)){
alert("Email must contain a valid e-mail address.\n");

}else{										
	
 
var namevalue=document.getElementById("newsletterform").name.value 
var emailvalue=document.getElementById("newsletterform").email.value 

      $.ajax({
          url: ajaxurlbroadcasts, 
          data: {
              'action':'email_newsletter_broadcasts_ajax_request', 
			  'name':namevalue,
			  'email':emailvalue
			  
          },
         
		  success:function(data) {
			
		     var error = data;
			
             if (error == false) {
				$(".success_msg_displlay").css("display","block");
             } else{              
				//alert(error);
              $(".error_msg_displlay").css("display","block");
			 }
          },
          error: function(errorThrown){
              window.alert(errorThrown);
          }
		  	  
      });
	  
	 //$('.ajax')[0].reset();
	  
    } 

		
	});
	
	
	
function checkMail(email)
{
	var x = email;
	var filter  = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	if (filter.test(x)) 
	{
	 return true;
	}
	else 
	{
	  return false;
	}
}	
	
});
</script>
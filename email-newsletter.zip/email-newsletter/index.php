<?php
/**
 * Plugin Name: Email Subscribers & Newsletters Broadcasts
 * Plugin URI:  https://profiles.wordpress.org/walexconcepts/
 * Description: Email Subscribers & Newsletters Broadcasts help you achieve all your newsletter related tasks effectively in one single place.
 * Version:     1.0
 * Author:      Awodeyi Adewale Emmanuel 
 * Author URI:  https://www.walexconcepts.com/
 * License:     GPLv2+
 */
if ( ! defined( 'ABSPATH' ) ) exit;
define('EMAIL_NEWSLETTER_BROADCASTS_PATH', __FILE__ . '/'); 
$installpath = explode('plugins', EMAIL_NEWSLETTER_BROADCASTS_PATH);
define('EMAIL_NEWSLETTER_BROADCASTS_INSTALLATION_PATH', dirname($installpath[0]) . '/');



wp_enqueue_script('jquery');


function email_newsletter_broadcasts_myplugin_ajaxurl() {
   echo esc_js('<script type="text/javascript">
           var ajaxurlbroadcasts = "' . admin_url('admin-ajax.php') . '";
         </script>');
		
?>		 

<?php		 
}
add_action('wp_head', 'email_newsletter_broadcasts_myplugin_ajaxurl');



function email_newsletter_broadcasts_call_after_install(){
 
$path = plugin_dir_path( __FILE__ ) . 'system/broadcasts_newsletters.sql';
$sql = file_get_contents($path);
require_once( EMAIL_NEWSLETTER_BROADCASTS_INSTALLATION_PATH . 'wp-admin/includes/upgrade.php' );
dbDelta( $sql );
}
register_activation_hook( __FILE__, 'email_newsletter_broadcasts_call_after_install' );




function email_newsletter_broadcasts_call_after_uninstall() {
global $wpdb;
$wpdb->query( 'DROP TABLE IF EXISTS broadcasts_newsletters' );
$wpdb->query( 'DROP TABLE IF EXISTS broadcasts_newslettersent' );
$wpdb->query( 'DROP TABLE IF EXISTS broadcasts_customers' );
$wpdb->query( 'DROP TABLE IF EXISTS broadcasts_mailnewsletter' );
}
register_uninstall_hook( __FILE__, 'email_newsletter_broadcasts_call_after_uninstall' );





function email_newsletter_broadcasts_ajax_request() {
    global $wpdb; 
	$dtadded=date('Y-m-d H:i:s');
	$name = sanitize_text_field($_REQUEST['name']);
	$email = sanitize_text_field($_REQUEST['email']);
	// check for duplicate
	$resultb = $wpdb->get_results($wpdb->prepare("select `varcustemail` from broadcasts_customers"));
	if(count($resultb)>0){	
		foreach($resultb as $result){
			if(($result->varcustemail)==$email)
			{
	        wp_send_json_error(
				
			);
			}else{
			  
				
			}
		}
	}	
	
	$sql = "INSERT INTO `broadcasts_customers` (`varcustfname`,`varcustemail`,`intnewsletter`,`intstatus`,`dtregtime` ) 
						VALUES ('$name','$email','1','1','$dtadded')";
              $insert=$wpdb->query( $wpdb->prepare($sql));	
}
add_action( 'wp_ajax_email_newsletter_broadcasts_ajax_request', 'email_newsletter_broadcasts_ajax_request' );
add_action( 'wp_ajax_nopriv_email_newsletter_broadcasts_ajax_request', 'email_newsletter_broadcasts_ajax_request' );





function email_newsletter_broadcasts_home() {
	
require plugin_dir_path( __FILE__ ) . 'include/myform.php';


}
add_shortcode('email_newsletter_broadcasts','email_newsletter_broadcasts_home');


function email_newsletter_broadcasts_editor(){	
?>
<script type="text/javascript">
			var textarea = document.getElementById('vartext');
			sceditor.create(textarea, {
				format: 'xhtml',
				width: '100%',
				
			});

		</script>
<?php 
}



function email_newsletter_broadcasts_allowed_html() {
	$allowed_tags = array(
		'a' => array(
			'class' => array(),
			'href'  => array(),
			'rel'   => array(),
			'title' => array(),
		),
		'abbr' => array(
			'title' => array(),
		),
		'b' => array(),
		'blockquote' => array(
			'cite'  => array(),
		),
		'cite' => array(
			'title' => array(),
		),
		'code' => array(),
		'del' => array(
			'datetime' => array(),
			'title' => array(),
		),
		'dd' => array(),
		'div' => array(
			'class' => array(),
			'title' => array(),
			'style' => array(),
		),
		'dl' => array(),
		'dt' => array(),
		'em' => array(),
		'h1' => array(
		'style' => array(),
		),
		'h2' => array(
		'style' => array(),
		),
		'h3' => array(
		'style' => array(),
		),
		'h4' => array(
		'style' => array(),
		),
		'h5' => array(
		'style' => array(),
		),
		'h6' => array(
		'style' => array(),
		),
		'i' => array(),
		'img' => array(
			'alt'    => array(),
			'class'  => array(),
			'height' => array(),
			'src'    => array(),
			'width'  => array(),
			'style' => array(),
		),
		'li' => array(
			'class' => array(),
		),
		'ol' => array(
			'class' => array(),
		),
		'p' => array(
			'class' => array(),
		),
		'q' => array(
			'cite' => array(),
			'title' => array(),
		),
		'span' => array(
			'class' => array(),
			'title' => array(),
			'style' => array(),
		),
		'iframe' => array(
		'src'             => array(),
		'height'          => array(),
		'width'           => array(),
		'frameborder'     => array(),
		'allowfullscreen' => array(),
		'style' => array(),
		),
		'source' => array(
		'src'             => array(),
		'height'          => array(),
		'width'           => array(),
		'type'     => array(),
		'style' => array(),
		),
		'embed' => array(
		'src'             => array(),
		'height'          => array(),
		'width'           => array(),
		'type'     => array(),
		'name'     => array(),
		'autoplay'     => array(),
		'fullscreen' => array(),
		'style' => array(),
		),
		'video' => array(
		'controls'             => array(),
		'height'          => array(),
		'width'           => array(),
		'autoplay'     => array(),
		'poster'     => array(),
		'title' => array(),
		'style' => array(),
		),
		'table' => array(
		'bgcolor'             => array(),
		'cellpadding'          => array(),
		'width'           => array(),
		'border'     => array(),
		'align'     => array(),
		'cellspacing' => array(),
		'style' => array(),
		),
		'td' => array(
		'height'          => array(),
		'width'           => array(),
		'style' => array(),
		),
		'tr' => array(
		'height'          => array(),
		'width'           => array(),
		'style' => array(),
		),
		'th' => array(
		'height'          => array(),
		'width'           => array(),
		'style' => array(),
		),
		'input' => array(
		'class' => array(),
		'id'    => array(),
		'name'  => array(),
		'value' => array(),
		'type'  => array(),
		),
		'button' => array(
		'class' => array(),
		'id'    => array(),
		'name'  => array(),
		'value' => array(),
		'type'  => array(),
		),
		'select' => array(
		'class'  => array(),
		'id'     => array(),
		'name'   => array(),
		'value'  => array(),
		'type'   => array(),
		),
		'option' => array(
		'selected' => array(),
		),
		'strike' => array(),
		'strong' => array(),
		'ul' => array(
			'class' => array(),
		),
	);
	
	return $allowed_tags;
}




function email_newsletter_broadcasts_admin_menu() {
    add_menu_page( 'NewsLetter..', 'NewsLetter..', null, 'email-subscribers-newsletters-broadcasts-administrator', '', plugin_dir_url( __FILE__ ) . 'adminicon.png');
    add_submenu_page( 'email-subscribers-newsletters-broadcasts-administrator', 'News Mail Settings..', 'News Mail Settings..', 'manage_options', 'settings_newsletter', 'newsletter_settings' );
	add_submenu_page( 'email-subscribers-newsletters-broadcasts-administrator', 'Add New NewsLetter..', 'Add New NewsLetter..', 'manage_options', 'addnews_newsletter', 'newsletter_addnews' );
	add_submenu_page( 'email-subscribers-newsletters-broadcasts-administrator', 'News Manager', 'News Manager', 'manage_options', 'newsmanager_newsletter', 'newsletter_newsmanager' );
	add_submenu_page( 'email-subscribers-newsletters-broadcasts-administrator', 'Subcriber Manager', 'Subcriber Manager', 'manage_options', 'subscriber_newsletter', 'newsletter_subcriber' );
	add_submenu_page( 'email-subscribers-newsletters-broadcasts-administrator', 'Send NewsLetter', 'Send NewsLetter', 'manage_options', 'send_newsletter', 'newsletter_send' );
	add_submenu_page( 'email-subscribers-newsletters-broadcasts-administrator', __( 'Help', 'email-subscribers-newsletters-broadcasts-administrator' ), __( 'Help', 'email-subscribers-newsletters-broadcasts-administrator' ), 'manage_options', 'help_newsletter', 'newsletter_help');
	add_submenu_page( null, 'Preview', 'Preview', 'manage_options', 'administrator_preview', 'newsletter_preview' );
	
	wp_enqueue_style( 'adminformstyle', plugins_url( 'admin/css/formstyle.css', __FILE__ ));
	wp_enqueue_style( 'admintemplate', plugins_url( 'admin/js/plugins/template/css/template.css', __FILE__ ));
	wp_enqueue_script('adminsendemail', plugins_url('admin/js/sendemail.js', __FILE__ ));
	
	wp_enqueue_script('adminmaailsettings', plugins_url('admin/js/mailsettings.js', __FILE__ ));
	wp_enqueue_script('admincustomer', plugins_url('admin/js/customer.js', __FILE__ ));
    
	wp_enqueue_script('sceditor.min.js', plugins_url('admin/js/sceditor.min.js', __FILE__ ));
	wp_enqueue_script('monocons.js', plugins_url('admin/js/monocons.js', __FILE__ ));
	wp_enqueue_script('bbcode.js', plugins_url('admin/js/bbcode.js', __FILE__ ));
	wp_enqueue_script('xhtml.js', plugins_url('admin/js/xhtml.js', __FILE__ ));
	wp_enqueue_style('default.min.css', plugins_url('admin/minified/themes/default.min.css', __FILE__ ));	

	
}
function newsletter_settings(){
	global $wpdb;
	require plugin_dir_path( __FILE__ ) . 'admin/system/msg.inc.php';
	require plugin_dir_path( __FILE__ ) . 'admin/mailnewsletter.php';
}
function newsletter_addnews(){
	global $wpdb;
	require plugin_dir_path( __FILE__ ) . 'admin/system/msg.inc.php';
	require plugin_dir_path( __FILE__ ) . 'admin/addnewsletter.php';
}
function newsletter_newsmanager(){
	global $wpdb;
	require plugin_dir_path( __FILE__ ) . 'admin/system/msg.inc.php';
	require plugin_dir_path( __FILE__ ) . 'admin/newsletter.php';
}
function newsletter_subcriber(){
	global $wpdb;
	require plugin_dir_path( __FILE__ ) . 'admin/system/msg.inc.php';
	require plugin_dir_path( __FILE__ ) . 'admin/customer.php';
}
function newsletter_send(){
	global $wpdb;
	require_once( EMAIL_NEWSLETTER_BROADCASTS_INSTALLATION_PATH . 'wp-includes/class-phpmailer.php' );
	require_once( EMAIL_NEWSLETTER_BROADCASTS_INSTALLATION_PATH . 'wp-includes/class-smtp.php' );
	require plugin_dir_path( __FILE__ ) . 'admin/system/msg.inc.php';
	require plugin_dir_path( __FILE__ ) . 'admin/sendnews.php';
}
function newsletter_help(){
	global $wpdb;
	require plugin_dir_path( __FILE__ ) . 'admin/newsletter_guide_help.php';
}
function newsletter_preview(){
	global $wpdb;
	require plugin_dir_path( __FILE__ ) . 'admin/system/msg.inc.php';
	require plugin_dir_path( __FILE__ ) . 'admin/newsletterdetails.php';
}
add_action('admin_menu', 'email_newsletter_broadcasts_admin_menu');



function email_newsletter_broadcasts_settings_link( $links){
	$links[] = '<a href="admin.php?page=help_newsletter">Help</a>' ;		
	$links[] = '<a target="_blank" href="https://walexconcepts.com/index.php?page=item&id=23">Go Premium!</a>' ;
	return $links;
}
add_filter( 'plugin_action_links_'.plugin_basename(__FILE__), 'email_newsletter_broadcasts_settings_link');

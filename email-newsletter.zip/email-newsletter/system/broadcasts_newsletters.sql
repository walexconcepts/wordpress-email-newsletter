CREATE TABLE `broadcasts_newsletters` (
  `intid` int(11) NOT NULL AUTO_INCREMENT,
  `varsubject` varchar(255) NOT NULL,
  `vartext` text NOT NULL,
  PRIMARY KEY (`intid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

CREATE TABLE `broadcasts_newslettersent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `intid` int(11) NOT NULL,
  `varcustemail` varchar(100) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `dtsentime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

CREATE TABLE `broadcasts_customers` (
  `intcusid` int(11) NOT NULL AUTO_INCREMENT,
  `varcustfname` varchar(100) NOT NULL,
  `varcustemail` varchar(100) NOT NULL,
  `intnewsletter` int(11) NOT NULL,
  `intstatus` int(11) NOT NULL,
  `dtregtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`intcusid`),
  UNIQUE KEY `varcustemail` (`varcustemail`),
  UNIQUE KEY `varcustemail_2` (`varcustemail`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=latin1;

CREATE TABLE `broadcasts_mailnewsletter` (
  `intid` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(250) NOT NULL,
  `login` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `port` varchar(250) NOT NULL,
  `frontend` varchar(250) NOT NULL,
  PRIMARY KEY (`intid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `broadcasts_mailnewsletter` (`intid`, `url`, `login`, `password`, `port`, `frontend`) VALUES
(1, 'mail.example.com', 'login@example.com', 'password', '25', 'htmlbox');



